# Changelog

Changes are grouped by local build/commit. Dates are local project dates. Entries describe implemented work and material limitations; a local commit is not a public release.

## Unreleased — 2026-11-03

- Added optional Demucs four-stem separation through the engine and CLI. A generated-tone smoke test produced four output files; musical separation quality is not yet validated.
- Added a VM application update builder and guest updater with per-file hashes and backups, plus upgrade and changes-since-baseline documentation. This does not change the guest driver or bundle optional model runtimes.
- Added an optional isolated Basic Pitch backend with `transcribe`, an engine component, note-event/MIDI outputs and provenance. A generated A440 tone produced MIDI note 69 in an offline integration run; general accuracy and instrument separation remain unvalidated.
- Added candidate reconstruction ranking with source hashes, residual reports by time interval, and optional equal-tempered coordinates on measured spectral peaks. These scores and labels do not independently identify instruments or note events.

## Local build 25633df — 2026-11-03

- Added offline `focus-band` frequency isolation and `audio-compare` residual analysis, exposed as engine components for agent-driven investigation. Tests cover filter selectivity, aligned subtraction, per-band Parseval energy and validation. These are not instrument separation or MIDI transcription.

## Local build 4aaa619 — 2026-11-03

- Restored the original StageJack selectable playback-loopback analyzer in Frankenjack and corrected the graph to show Earnest's seven reflection EQ filters. Offline checks cover sample decoding, missing input and the curve; live monitor behavior still needs verification.
- Added a suite updater design covering staged installation, compatibility, user data and rollback; it is not implemented.

## Local build 93a7ce8 — 2026-11-03

- Added in-stream replacement room profiles with a 120 ms warm-up and 150 ms linear crossfade, plus offline continuity and invalid-profile checks. Endpoint changes still restart the bridge; live behavior and CPU headroom remain unverified.

## Local build c87e84f — 2026-11-03

- Added a saved room selector to Frankenjack Advanced Mix; room changes still rebuild and restart the bridge. Offline checks cover the selector and missing-file handling, not live switching.

## Local build 489e0d8 — 2026-11-03

- Added file-based decay, late-tail energy, and tail-duration CLI commands with independent baseline scaling, explicit extended range, and overwrite protection.
- Documented a research comparison with Pyroomacoustics and a possible measured-scene evaluation; this is not a validation result.

## Local build 4f57715 — 2026-11-03

- Wired the Stage Width control to a smoothed, unity-by-default stereo mid/side stage independent of the room, with offline mono, unity and widened checks. Other spatial positioning controls remain unwired.

## Local build e877184 — 2026-11-03

- Added separate unity-by-default seven-band direct EQ in Frankenjack Advanced Mix and the native bridge, independent of reflection EQ. Offline tests verify ±6 dB at every band center, path isolation, and UI file bindings.

## Local build 9bb7239 — 2026-11-03

- Added an independent decay-time multiplier to the room engine, Room Studio, and Frankenjack Advanced Mix; retained the separate tail cutoff control. Added synthesized decay-slope, profile, adapter and offline UI-binding checks.

## Local build 8fba240 — 2026-11-03

- Added independent, common in-phase and opposite-polarity source assumptions to the room-field viewer, plus validated custom complex correlation matrices in the engine/CLI. Exact cancellation and missing near-source values are represented separately when a nonzero reference exists.

## Local build 6ce0354 — 2026-11-03

- Added an interactive, relative, single-frequency room-field slice and CLI export using coherent image paths within each source and independent powers across sources. The map is a limited point-sampled preview, not a measured SPL or late-field simulation.

## Local build c773cd3 — 2026-11-03

- Added finite-window C50, C80, D50 and center-time energy diagnostics per modeled source/listener band, with boundary and zero-energy checks.

## Local build 8a9f011 — 2026-11-03

- Added optional air absorption to Sabine/Eyring decay, decay fitting and the existing diffuse energy approximation, using the same `4mV` correction. Added equation, air-only and fit-consistency checks.

## Local build 1102fb3 — 2026-11-03

- Added cross-spectral propagation for multiple correlated sources and receivers, with Hermitian/positive-semidefinite validation and a CLI. An explicit-path adapter uses the existing room solution; it does not include the diffuse statistical tail or calibrated absolute SPL.
- Corrected the equation sheet's IACC, source directivity, air attenuation, specular-scattering and cross-spectral convention descriptions.
- Added equation and integration checks under `tests` and a small independent stereo source-spectrum example.

## Local build b7e0b66 — 2026-11-03

- Expanded Room Studio with editable geometry, materials, source/listener controls, decay chart, drag and keyboard interaction, room export, and reconstructable instruction export. Rectangular geometry only.

## Local build 092e434 — 2026-11-03

- Added an experimental supervised instrument reference matcher and CLI training/identification. Real-world accuracy and full-song identification remain unvalidated.

## Local build bfc8387 — 2026-11-03

- Added optional atmospheric attenuation and ideal source/receiver directionality on explicit paths, ideal resonator modes, a frequency trace, room editor, and expanded Frankenjack controls with equation and offline checks.

## Baseline 9cabc1e — 2026-11-02

- Consolidated the experimental room engine, configurable lab, math and documentation baseline. See Git history for earlier work.
